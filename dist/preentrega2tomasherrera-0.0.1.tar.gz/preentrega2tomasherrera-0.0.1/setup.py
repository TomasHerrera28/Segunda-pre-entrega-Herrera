from setuptools import setup

setup(
    name="PreEntrega2TomasHerrera",
    version="0.0.1",
    packages=["mi_paquete_cliente"],
    description="Un paquete para modelar clientes en una página de compras",
    author="Tomas Herrera",
    author_email="tomyherrera28@gmail.com",
)